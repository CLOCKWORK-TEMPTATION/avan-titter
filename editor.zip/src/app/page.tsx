"use client";

import ScreenplayEditorEnhanced from "../components/ScreenplayEditorEnhanced";

export default function HomePage() {
  return <ScreenplayEditorEnhanced />;
}